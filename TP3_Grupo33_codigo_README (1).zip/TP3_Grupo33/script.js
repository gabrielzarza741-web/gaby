// Los desplegables utilizan <details> y <summary> nativos de HTML.
// No se requieren APIs, backend ni ejecución de IA.
// Archivo reservado para futuras mejoras de accesibilidad e interacción.
