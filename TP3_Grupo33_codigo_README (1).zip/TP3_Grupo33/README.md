# TP3 — Dos sentencias, dos soluciones

**Equipo:** Grupo 33 — IFTS 29  
**Materia:** Desarrollo de Sistemas Web Front-End  
**Entrega:** 26/11/2026

## Estado del proyecto

**Prototipo de ejemplo, no entrega final.** La startup «Grupo 33 — Soluciones Digitales», su logotipo y las dos sentencias fueron **inventados para ilustrar la consigna**. Deben reemplazarse por la startup y el bloque realmente asignados por el docente, creados originalmente por estudiantes del IFTS 16, e incorporar el logo original completo.

## Descripción

Landing page informativa que presenta dos propuestas de flujos de decisión para solicitudes de soporte técnico. Incluye diagramas, caminos verdadero/falso y desplegables con entradas, condiciones, acciones, excepciones e intervención humana. No ejecuta IA, no consume APIs ni utiliza backend.

## Sentencias de ejemplo (NO oficiales)

1. **Prioridad:** Si el sistema no funciona **Y** el problema afecta a varios usuarios, la solicitud es urgente; en caso contrario, es normal.
2. **Asignación:** Si existe un técnico disponible **Y** el problema puede resolverse remotamente, se asigna un técnico; en caso contrario, se deriva a un encargado.

## Tecnologías

- HTML5: estructura y desplegables accesibles mediante `details` y `summary`.
- CSS3: diseño de escritorio adaptable y diagramas visuales.
- JavaScript: archivo preparado, sin lógica necesaria para los desplegables nativos.

## Cómo ejecutar

Abrir `index.html` en un navegador. No requiere instalación ni servidor.

## Integrantes y aportes

| Integrante | Aporte concreto |
|---|---|
| [Nombre real] | [Trabajo realizado] |
| [Nombre real] | [Trabajo realizado] |
| [Nombre real] | [Trabajo realizado] |

## Construcción agéntica y herramientas utilizadas

La consigna exige desarrollar e iterar el código **100 % mediante agentes de programación**, sin editarlo manualmente. Registrar de forma verídica las herramientas utilizadas:

| Aplicación / entorno | Modelo exacto | Uso realizado |
|---|---|---|
| ChatGPT | [Completar con modelo utilizado o «modelo no informado»] | Generación inicial de prototipo y documentación a partir de instrucciones del usuario |
| [Agente de programación empleado] | [Modelo exacto o «modelo no informado»] | [Indicar las tareas reales] |

No declarar herramientas, pruebas o iteraciones que no se hayan realizado.

## Registro de instrucciones e iteraciones

- **Instrucción inicial:** Crear una landing para el Grupo 33 con dos sentencias de ejemplo, diagramas de decisión, desplegables y README.
- **Problema detectado:** [Completar tras la revisión real].
- **Corrección solicitada al agente:** [Completar tras la iteración real].
- **Resultado comprobado:** [Completar después de probarlo].

## Pruebas pendientes

- [ ] Verificar la página en escritorio.
- [ ] Probar desplegables con clic y teclado.
- [ ] Comprobar caminos verdadero y falso de ambos diagramas.
- [ ] Sustituir logo, startup y sentencias de ejemplo por los oficiales.
- [ ] Completar integrantes, aportes y registro real de IA.
- [ ] Publicar repositorio público en GitHub.
- [ ] Desplegar en Vercel, Netlify o GitHub Pages.
- [ ] Abrir ambos enlaces en ventana incógnita sin iniciar sesión.

**Repositorio:** [Agregar URL pública]  
**Landing publicada:** [Agregar URL pública]
