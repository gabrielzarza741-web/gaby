using System;
using System.Drawing;
using System.Windows.Forms;
using System.Reflection;
using System.Threading;
using ClubDeportivo;
class UiSmoke
{
    static object Field(object o,string name){return o.GetType().GetField(name,BindingFlags.Instance|BindingFlags.NonPublic).GetValue(o);}
    static void Pump(){for(int i=0;i<100;i++){Application.DoEvents();Thread.Sleep(10);}}
    static void Save(Form f,string path){using(var b=new Bitmap(f.Width,f.Height)){f.DrawToBitmap(b,new Rectangle(0,0,b.Width,b.Height));b.Save(path);}}
    [STAThread] static void Main(string[] args)
    {
        Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
        string dir=args[0];System.IO.Directory.CreateDirectory(dir);
        var asm=typeof(MainForm).Assembly;
        var repo=(IClubRepository)asm.GetType("ClubDeportivo.MemoryRepository").GetMethod("CreateDemo").Invoke(null,new object[]{DateTime.Today});
        using(var f=new MainForm(new ClubService(repo,()=>DateTime.Today),true))
        {
            f.Opacity=0;f.ShowInTaskbar=false;f.Show();Pump();
            if(((DataGridView)Field(f,"people")).Rows.Count!=3)throw new Exception("No se cargó el listado inicial.");
            Save(f,System.IO.Path.Combine(dir,"01-personas.png"));
            var tabs=(TabControl)Field(f,"tabs");tabs.SelectedIndex=1;Pump();
            var combo=(ComboBox)Field(f,"payPerson");combo.SelectedIndex=1;
            typeof(MainForm).GetMethod("LoadPayments",BindingFlags.NonPublic|BindingFlags.Instance).Invoke(f,null);Pump();
            if(((DataGridView)Field(f,"payments")).Rows.Count!=1)throw new Exception("No se cargó el historial de pagos.");
            Save(f,System.IO.Path.Combine(dir,"02-pagos.png"));
            tabs.SelectedIndex=2;
            ((CheckBox)Field(f,"overdue")).Checked=true;
            var dues=(DataGridView)Field(f,"dues");dues.DataSource=repo.Vencimientos(DateTime.Today,true);Pump();
            if(dues.Rows.Count!=2)throw new Exception("Vencimientos incorrectos.");
            Save(f,System.IO.Path.Combine(dir,"03-vencimientos.png"));f.Close();
        }
        using(var f=new ConnectionForm())
        {f.Opacity=0;f.ShowInTaskbar=false;f.Show();Pump();Save(f,System.IO.Path.Combine(dir,"00-conexion.png"));f.Close();}
        System.IO.File.WriteAllText(System.IO.Path.Combine(dir,"resultado-interfaz.txt"),"OK: carga inicial de 3 personas, historial de un pago y reporte de dos socios. Cuatro formularios renderizados con DrawToBitmap en modo de demostración. No verifica MySQL.");
    }
}
