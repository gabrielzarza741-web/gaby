$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$compilerPath = Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319/csc.exe'
$runnerPath = Join-Path $projectRoot 'Ejecutable/Release/RevisionInterfaz.exe'
$mainPath = Join-Path $projectRoot 'Ejecutable/Release/ClubDeportivo.exe'
$sourcePath = Join-Path $PSScriptRoot 'RevisionInterfaz.cs'
$captureDir = Join-Path $PSScriptRoot 'CapturasDemo'
& $compilerPath /nologo /target:winexe /platform:x64 "/out:$runnerPath" "/reference:$mainPath" /reference:System.Windows.Forms.dll /reference:System.Drawing.dll /reference:System.Data.dll $sourcePath
if ($LASTEXITCODE -ne 0) { throw 'No se pudo compilar la prueba de interfaz.' }
try {
    $uiProcess = Start-Process -FilePath $runnerPath -ArgumentList ('"' + $captureDir + '"') -Wait -PassThru -WindowStyle Hidden
    if ($uiProcess.ExitCode -ne 0) { throw 'Falló la prueba de interfaz.' }
    Get-Content -LiteralPath (Join-Path $captureDir 'resultado-interfaz.txt')
} finally {
    Remove-Item -LiteralPath $runnerPath -Force
}
