# Club Deportivo - Windows Forms y MySQL

Implementación educativa en C# para continuar el Proyecto Integrador. Incluye código editable, ejecutable x64, script SQL, demostración y pruebas. Debe contrastarse con las resoluciones y diagramas específicos de la cursada: no se proporcionaron esos materiales ni un proyecto anterior.

## Inicio rápido sin base de datos

1. Extraer todo el ZIP en una carpeta.
2. Abrir `abrir-demostracion.cmd`.
3. Recorrer Personas y carnet, Pagos y comprobantes, y Vencimientos de socios.

La franja superior identifica claramente el modo de demostración. Sus tres personas son ficticias, los importes iniciales son ejemplos y los cambios se pierden al cerrar. Para persistir datos hay que usar el inicio normal con MySQL.

## Requisitos del modo normal

- Windows de 64 bits con .NET Framework 4.8.
- Servidor MySQL 8.0.16 o posterior, local o accesible por red.
- MySQL Connector/ODBC de 64 bits registrado en Windows. No confundir MySQL Workbench con el servidor ni con el controlador.
- Un usuario MySQL con permisos para acceder a las tablas y ejecutar los procedimientos del proyecto. La importación inicial requiere permisos para crear la base, tablas y rutinas.

Se utiliza ADO.NET mediante `System.Data.Odbc`, incluido en .NET Framework, y el controlador oficial de MySQL. No requiere MySql.Data.dll ni paquetes NuGet. Los formularios se construyen en código; no hay archivos Designer ni diseño visual arrastrando controles.

Controlador oficial y guía de instalación:
- https://dev.mysql.com/downloads/connector/odbc/
- https://dev.mysql.com/doc/connector-odbc/en/connector-odbc-installation-binary-windows.html

## Preparar MySQL e ingresar

1. En MySQL Workbench, conectarse al servidor con un usuario autorizado.
2. Abrir `DB/club_deportivo.sql` y ejecutar el script completo. Crea `club_deportivo_pif`, tres tablas y siete procedimientos. No elimina datos existentes. Reejecutarlo reemplaza los procedimientos del proyecto.
3. Instalar Connector/ODBC x64 y volver a abrir el programa para que lo detecte.
4. Abrir `Ejecutable/Release/ClubDeportivo.exe`.
5. Elegir el controlador e ingresar servidor, puerto, base, usuario y contraseña por teclado. El puerto inicial es 3306: modificarlo si el servidor usa otro.
6. Pulsar **Conectar e ingresar**. La aplicación abre MySQL y consulta la versión del esquema antes de mostrar el menú.

La contraseña no se guarda en archivos. El usuario ingresado es una cuenta de MySQL: no se implementó un segundo sistema de cuentas de aplicación o de roles. Para servidores remotos, configurar la protección de transporte en el controlador y el servidor según el entorno de la institución.

## Funciones y reglas implementadas

### Personas

- Alta de socios y no socios con DNI, nombre, apellido, nacimiento y vigencia del apto físico.
- DNI de 7 a 9 dígitos, sin puntos, único para ambos tipos. Es la clave primaria.
- Apto presentado y verificado por el operador; no se admite un vencimiento anterior al alta. El apto es válido durante su fecha de vencimiento inclusive.
- Consulta por DNI o apellido y renovación de vigencia del apto.
- Carnet para socios: vista previa, guardado en TXT e impresión. El DNI funciona como número de socio. El carnet acredita inscripción; no comprueba por sí mismo cuota vigente ni habilitación de acceso.

### Pagos

- Socio: cuota mensual desde la fecha de cobro hasta la misma fecha del mes siguiente. Los fines de mes se ajustan al último día válido.
- No socio: cuota diaria desde la fecha de cobro hasta el día siguiente.
- El vencimiento de la cuota es **exclusivo**: si vence el 15, cubre hasta el 14 inclusive. El apto físico utiliza un criterio distinto y es inclusivo.
- El operador ingresa el importe positivo según la tarifa del club; no se inventó una tarifa oficial. Se trabaja en pesos, con dos decimales.
- No se permite otro cobro mientras exista un período vigente. Se puede renovar el día del vencimiento o después. No se calculan intereses, deudas históricas ni pagos anticipados.
- El apto debe estar vigente al cobrar. No se exige que cubra todo el mes pagado: si vence durante ese mes, debe renovarse para conservar su vigencia.
- Confirmación del cobro, historial y comprobante interno guardable e imprimible. El comprobante no es una factura fiscal.
- Los cobros reales se resuelven dentro de una transacción MySQL, con bloqueo de la persona para serializar cobros simultáneos y restricción única por período.

### Vencimientos

- Lista de socios cuyo último período registrado vence en la fecha elegida.
- Opción para incluir vencimientos anteriores.
- Un socio sin pagos tiene su primer vencimiento en la fecha de alta.
- Se consulta el último período registrado; no se reconstruye el estado histórico de una fecha pasada. Los no socios no aparecen en este reporte.

## Organización del código y los cuatro pilares

| Pilar | Aplicación concreta |
|---|---|
| Abstracción | `Persona` abstracta define datos y operaciones comunes. `IClubRepository` define el contrato de persistencia. |
| Encapsulamiento | Propiedades de `Persona` con modificación privada; cambios de apto a través de un método que valida. |
| Herencia | `Socio` y `NoSocio` derivan de `Persona`. |
| Polimorfismo | Ambas clases redefinen `TipoPago` y `FinPeriodo`: un mes o un día. `Pago` usa una referencia a `Persona`. |

Archivos principales, dentro de `Codigo/ClubDeportivo`:

- `Domain.cs`: entidades, reglas, interfaz de repositorio y servicio.
- `MySqlRepository.cs`: consultas parametrizadas y llamadas a procedimientos mediante ODBC.
- `Forms.cs`: conexión, menú, registros, cobros, vencimientos, carnet y comprobante.
- `Program.cs`: inicio normal, demostración y pruebas.
- `DemoAndTests.cs`: repositorio temporal de demostración y 25 pruebas automáticas.

Recorrido de inscripción: botón Registrar persona -> `ClubService.Inscribir` -> `Socio` o `NoSocio` -> `IClubRepository.Agregar` -> `MySqlRepository.Agregar` -> `sp_registrar_persona` -> tabla `personas`.

Recorrido de cobro: botón Registrar pago -> `ClubService.Cobrar` -> `MySqlRepository.RegistrarPago` -> `sp_registrar_pago` -> bloqueo, validaciones e inserción -> comprobante. La regla de duración se expresa en el dominio y se replica en SQL, que es quien decide y almacena el período en modo normal.

## Abrir, compilar y probar

En Visual Studio Community, abrir `Codigo/ClubDeportivo.sln`, con las herramientas de escritorio .NET y el paquete de desarrollo de .NET Framework 4.8. Compilar para x64. La salida se guarda en `Ejecutable/Release`.

También se puede ejecutar `compilar.ps1` desde PowerShell: utiliza el compilador de .NET Framework de Windows. Después ejecutar `probar.ps1`. No es necesario cambiar permanentemente la política de ejecución del equipo: si la institución bloquea scripts, usar Visual Studio o solicitar el procedimiento autorizado.

El ejecutable acepta:

```
ClubDeportivo.exe
ClubDeportivo.exe --demo
ClubDeportivo.exe --autoprueba "C:\carpeta\resultado.txt"
```

## Estado de verificación

- Compilación x64 realizada sin advertencias.
- 25 pruebas del dominio y servicio aprobadas. Resultado en `Pruebas/resultado-pruebas.txt`.
- Renderizado de cuatro pantallas y comprobación de carga de personas, historial y vencimientos en demostración. Evidencias en `Pruebas/CapturasDemo`.
- **Pendiente:** instalar el controlador y probar importación, procedimientos, permisos, persistencia, concurrencia y conexión contra un servidor MySQL real. En este equipo no se detectó el controlador ODBC y no se proporcionó una conexión a MySQL. Las pruebas en memoria no reemplazan esa validación.
- También falta la prueba en otra PC solicitada por la cátedra y la adaptación a las convenciones concretas de las fases anteriores.

## Prueba manual de integración antes de la entrega

1. Importar el SQL en una base de prueba y entrar con parámetros correctos. Verificar también credenciales o base incorrectas.
2. Registrar un socio con apto vigente. Consultar la fila en `personas`.
3. Intentar repetir su DNI como socio y como no socio: ambos deben rechazarse sin agregar filas.
4. Intentar registrar sin verificación del apto y con fecha de apto pasada.
5. Registrar un no socio. Emitir carnet del socio; comprobar que el no socio no puede emitirlo.
6. Registrar cuota mensual y diaria con importes positivos y verificar filas en `pagos` y comprobantes.
7. Repetir un cobro vigente, incluso desde dos instancias: solo debe existir un pago para el período.
8. Consultar un vencimiento exacto y luego incluir anteriores. Corroborar el resultado con `MAX(hasta)` de cada socio.
9. Cerrar y reabrir el programa: los datos reales deben conservarse en MySQL.
10. Probar impresión o guardado de carnet/comprobante y ejecutar en otra computadora con los requisitos instalados.

No se generó un video, ni se atribuyen tareas a integrantes desconocidos. Este paquete es la implementación para continuar el trabajo, no el comprimido final con el nombre de comisión y equipo.
