using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace ClubDeportivo
{
    // Abstracción: Persona reúne el estado común y define el comportamiento del pago.
    public abstract class Persona
    {
        public string Dni { get; private set; }
        public string Nombre { get; private set; }
        public string Apellido { get; private set; }
        public DateTime Nacimiento { get; private set; }
        public DateTime Alta { get; private set; }
        public DateTime AptoHasta { get; private set; }
        public abstract string Tipo { get; }
        public abstract string TipoPago { get; }
        public abstract DateTime FinPeriodo(DateTime desde);

        protected Persona(string dni, string nombre, string apellido, DateTime nacimiento,
                          DateTime alta, DateTime aptoHasta)
        {
            dni = (dni ?? "").Trim();
            if (dni.Length < 7 || dni.Length > 9 || !dni.All(c => c >= '0' && c <= '9'))
                throw new ArgumentException("El DNI debe tener entre 7 y 9 dígitos, sin puntos.");
            if (String.IsNullOrWhiteSpace(nombre) || nombre.Trim().Length > 80 ||
                String.IsNullOrWhiteSpace(apellido) || apellido.Trim().Length > 80)
                throw new ArgumentException("Complete nombre y apellido (hasta 80 caracteres cada uno).");
            if (nacimiento.Date >= alta.Date || nacimiento.Date < alta.Date.AddYears(-120))
                throw new ArgumentException("La fecha de nacimiento debe ser anterior al alta y no superar 120 años.");
            if (aptoHasta.Date < alta.Date)
                throw new ArgumentException("Se requiere apto físico vigente para la inscripción.");
            Dni = dni; Nombre = nombre.Trim(); Apellido = apellido.Trim();
            Nacimiento = nacimiento.Date; Alta = alta.Date; AptoHasta = aptoHasta.Date;
        }
        public void ActualizarApto(DateTime hasta, DateTime hoy)
        {
            if (hasta.Date < hoy.Date) throw new ArgumentException("El apto físico debe estar vigente.");
            AptoHasta = hasta.Date;
        }
    }

    // Herencia y polimorfismo: cada tipo determina su cuota y duración.
    public sealed class Socio : Persona
    {
        public override string Tipo { get { return "SOCIO"; } }
        public override string TipoPago { get { return "MENSUAL"; } }
        public override DateTime FinPeriodo(DateTime desde) { return desde.Date.AddMonths(1); }
        public Socio(string dni, string nombre, string apellido, DateTime nacimiento, DateTime alta, DateTime apto)
            : base(dni, nombre, apellido, nacimiento, alta, apto) { }
    }
    public sealed class NoSocio : Persona
    {
        public override string Tipo { get { return "NO_SOCIO"; } }
        public override string TipoPago { get { return "DIARIA"; } }
        public override DateTime FinPeriodo(DateTime desde) { return desde.Date.AddDays(1); }
        public NoSocio(string dni, string nombre, string apellido, DateTime nacimiento, DateTime alta, DateTime apto)
            : base(dni, nombre, apellido, nacimiento, alta, apto) { }
    }

    public sealed class Pago
    {
        public long Id { get; set; }
        public string Dni { get; private set; }
        public string Tipo { get; private set; }
        public DateTime Fecha { get; private set; }
        public DateTime Desde { get; private set; }
        // Hasta es exclusivo: una cuota hasta el 15 vence al comenzar el día 15.
        public DateTime Hasta { get; private set; }
        public decimal Importe { get; private set; }
        public Pago(Persona persona, DateTime fecha, DateTime desde, decimal importe)
        {
            if (importe <= 0 || importe > 99999999.99m)
                throw new ArgumentException("El importe debe ser mayor que cero y hasta 99.999.999,99.");
            Dni = persona.Dni; Tipo = persona.TipoPago; Fecha = fecha.Date;
            Desde = desde.Date; Hasta = persona.FinPeriodo(desde); Importe = importe;
        }
        private Pago() { }
        public static Pago DesdeRegistro(long id, string dni, string tipo, DateTime fecha,
                                          DateTime desde, DateTime hasta, decimal importe)
        {
            return new Pago { Id=id, Dni=dni, Tipo=tipo, Fecha=fecha.Date,
                Desde=desde.Date, Hasta=hasta.Date, Importe=importe };
        }
    }

    public sealed class Vencimiento
    {
        public string Dni { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public DateTime Fecha { get; set; }
        public string Estado { get; set; }
    }

    public interface IClubRepository
    {
        IList<Persona> ListarPersonas();
        void Agregar(Persona persona);
        void ActualizarApto(string dni, DateTime hasta, DateTime hoy);
        IList<Pago> ListarPagos(string dni);
        Pago RegistrarPago(string dni, DateTime fecha, decimal importe);
        IList<Vencimiento> Vencimientos(DateTime fecha, bool incluirAnteriores);
    }

    public sealed class ClubService
    {
        private readonly IClubRepository repository;
        private readonly Func<DateTime> reloj;
        public ClubService(IClubRepository repository, Func<DateTime> reloj)
        { this.repository = repository; this.reloj = reloj; }
        public IList<Persona> Personas() { return repository.ListarPersonas(); }
        public IList<Pago> Pagos(string dni) { return repository.ListarPagos(dni); }
        public void Inscribir(string tipo, string dni, string nombre, string apellido,
                              DateTime nacimiento, DateTime apto)
        {
            DateTime hoy = reloj().Date;
            Persona persona;
            if (tipo == "SOCIO") persona = new Socio(dni, nombre, apellido, nacimiento, hoy, apto);
            else if (tipo == "NO_SOCIO") persona = new NoSocio(dni, nombre, apellido, nacimiento, hoy, apto);
            else throw new ArgumentException("Seleccione socio o no socio.");
            repository.Agregar(persona);
        }
        public void RenovarApto(string dni, DateTime hasta)
        {
            if (hasta.Date < reloj().Date) throw new ArgumentException("El apto físico debe estar vigente.");
            repository.ActualizarApto(dni, hasta.Date, reloj().Date);
        }
        public Pago Cobrar(string dni, decimal importe)
        { return repository.RegistrarPago(dni, reloj().Date, importe); }
        public IList<Vencimiento> Vencimientos(DateTime fecha, bool anteriores)
        { return repository.Vencimientos(fecha.Date, anteriores); }
        public string Carnet(Persona persona)
        {
            if (persona.Tipo != "SOCIO") throw new InvalidOperationException("El carnet se emite para socios.");
            return "CLUB DEPORTIVO\r\nCARNET DE SOCIO\r\n\r\n" + persona.Apellido + ", " + persona.Nombre +
                "\r\nDNI / Nro. de socio: " + persona.Dni + "\r\nAlta: " + persona.Alta.ToString("dd/MM/yyyy") +
                "\r\nApto físico hasta: " + persona.AptoHasta.ToString("dd/MM/yyyy") +
                "\r\nEmitido: " + reloj().ToString("dd/MM/yyyy") +
                "\r\n\r\nEl carnet acredita inscripción. No acredita cuota paga ni habilitación de ingreso.";
        }
    }
}
