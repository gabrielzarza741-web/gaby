using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClubDeportivo
{
    // Solo para demostración y pruebas. El modo normal SIEMPRE utiliza MySQL.
    internal sealed class MemoryRepository : IClubRepository
    {
        private readonly List<Persona> personas=new List<Persona>();
        private readonly List<Pago> pagos=new List<Pago>();
        public IList<Persona> ListarPersonas(){return personas.OrderBy(p=>p.Apellido).ThenBy(p=>p.Nombre).ToList();}
        public void Agregar(Persona p)
        {
            if(personas.Any(x=>x.Dni==p.Dni))throw new InvalidOperationException("Ya existe una persona con ese DNI.");
            personas.Add(p);
        }
        private Persona Find(string dni)
        {
            var p=personas.FirstOrDefault(x=>x.Dni==dni);
            if(p==null)throw new ArgumentException("Persona no encontrada.");return p;
        }
        public void ActualizarApto(string dni,DateTime hasta,DateTime hoy){Find(dni).ActualizarApto(hasta,hoy);}
        public IList<Pago> ListarPagos(string dni){return pagos.Where(p=>p.Dni==dni).OrderByDescending(p=>p.Id).ToList();}
        public Pago RegistrarPago(string dni,DateTime fecha,decimal importe)
        {
            var person=Find(dni);
            if(fecha.Date<person.Alta)throw new ArgumentException("El pago no puede ser anterior al alta.");
            if(person.AptoHasta<fecha.Date)throw new InvalidOperationException("Renueve el apto físico antes de registrar un pago.");
            if(pagos.Any(p=>p.Dni==dni&&p.Hasta>fecha.Date))throw new InvalidOperationException("La persona ya tiene un período pago vigente.");
            var payment=new Pago(person,fecha,fecha,importe){Id=pagos.Count+1};pagos.Add(payment);return payment;
        }
        public IList<Vencimiento> Vencimientos(DateTime fecha,bool anteriores)
        {
            var result=new List<Vencimiento>();
            foreach(var p in personas.Where(p=>p.Tipo=="SOCIO"&&p.Alta<=fecha.Date))
            {
                var last=pagos.Where(g=>g.Dni==p.Dni).Select(g=>(DateTime?)g.Hasta).Max();
                DateTime due=last??p.Alta;
                if((anteriores&&due<=fecha.Date)||(!anteriores&&due==fecha.Date))
                    result.Add(new Vencimiento{Dni=p.Dni,Nombre=p.Nombre,Apellido=p.Apellido,Fecha=due,
                        Estado=last==null?"SIN PAGOS":due==fecha.Date?"VENCE EN LA FECHA":"VENCIDA"});
            }
            return result.OrderBy(r=>r.Fecha).ThenBy(r=>r.Apellido).ToList();
        }
        public static MemoryRepository CreateDemo(DateTime hoy)
        {
            var repo=new MemoryRepository();
            repo.Agregar(new Socio("30123456","Ana","Gómez",new DateTime(1985,4,12),hoy.AddDays(-35),hoy.AddMonths(6)));
            repo.Agregar(new Socio("32456789","Diego","Pérez",new DateTime(1988,8,20),hoy,hoy.AddYears(1)));
            repo.Agregar(new NoSocio("35789123","Lucía","Fernández",new DateTime(1990,2,15),hoy,hoy.AddMonths(4)));
            repo.RegistrarPago("30123456",hoy.AddDays(-35),15000m);
            return repo;
        }
    }
    internal static class SelfTests
    {
        private static void Assert(bool value,string message){if(!value)throw new Exception(message);}
        private static void Fails(Action work)
        {bool thrown=false;try{work();}catch(ArgumentException){thrown=true;}catch(InvalidOperationException){thrown=true;}Assert(thrown,"Se esperaba rechazo de la operación.");}
        public static int Run(out string report)
        {
            var log=new StringBuilder("PRUEBAS AUTOMATICAS - DOMINIO Y SERVICIO\r\nRepositorio de prueba en memoria. No verifica MySQL ni el controlador ODBC.\r\n\r\n");
            int total=0,failed=0;
            Action<string,Action> test=(name,work)=>{total++;try{work();log.AppendLine("OK - "+name);}catch(Exception ex){failed++;log.AppendLine("ERROR - "+name+": "+ex.Message);}};
            DateTime today=new DateTime(2026,1,31);
            Func<Persona> member=()=>new Socio("30123456"," Ana ","Gómez",new DateTime(1990,1,1),today,today.AddYears(1));
            test("Inscripción válida normaliza nombres",()=>{var p=member();Assert(p.Nombre=="Ana"&&p.Dni=="30123456","Datos incorrectos.");});
            test("DNI con letras rechazado",()=>Fails(()=>new Socio("ABC12345","Ana","Gómez",new DateTime(1990,1,1),today,today)));
            test("DNI corto rechazado",()=>Fails(()=>new Socio("123456","Ana","Gómez",new DateTime(1990,1,1),today,today)));
            test("DNI con puntos rechazado",()=>Fails(()=>new Socio("30.123.456","Ana","Gómez",new DateTime(1990,1,1),today,today)));
            test("Nombre vacío rechazado",()=>Fails(()=>new Socio("30123456"," ","Gómez",new DateTime(1990,1,1),today,today)));
            test("Nacimiento futuro rechazado",()=>Fails(()=>new Socio("30123456","Ana","Gómez",today.AddDays(1),today,today)));
            test("Apto vencido impide inscripción",()=>Fails(()=>new Socio("30123456","Ana","Gómez",new DateTime(1990,1,1),today,today.AddDays(-1))));
            test("Apto vence hoy: inscripción permitida",()=>{new Socio("30123456","Ana","Gómez",new DateTime(1990,1,1),today,today);});
            test("Socio: mes desde 31 de enero",()=>Assert(member().FinPeriodo(today)==new DateTime(2026,2,28),"Fin de mes incorrecto."));
            test("Socio: febrero bisiesto",()=>Assert(member().FinPeriodo(new DateTime(2024,1,31))==new DateTime(2024,2,29),"Año bisiesto incorrecto."));
            test("No socio: día con cambio de año",()=>{Persona p=new NoSocio("30123456","Ana","Gómez",new DateTime(1990,1,1),today,today);Assert(p.FinPeriodo(new DateTime(2026,12,31))==new DateTime(2027,1,1),"Día incorrecto.");});
            test("Pago cero rechazado",()=>Fails(()=>new Pago(member(),today,today,0)));
            test("Pago negativo rechazado",()=>Fails(()=>new Pago(member(),today,today,-1)));
            test("Importe fuera de rango rechazado",()=>Fails(()=>new Pago(member(),today,today,100000000m)));
            test("DNI único entre socios y no socios",()=>{var r=new MemoryRepository();r.Agregar(member());Fails(()=>r.Agregar(new NoSocio("30123456","Ana","Gómez",new DateTime(1990,1,1),today,today)));});
            test("No se cobra dos veces un período vigente",()=>{var r=new MemoryRepository();r.Agregar(member());r.RegistrarPago("30123456",today,100);Fails(()=>r.RegistrarPago("30123456",today,100));Assert(r.ListarPagos("30123456").Count==1,"Se duplicó el cobro.");});
            test("Renovación en el día de vencimiento",()=>{var r=new MemoryRepository();r.Agregar(member());var first=r.RegistrarPago("30123456",today,100);var next=r.RegistrarPago("30123456",first.Hasta,100);Assert(next.Desde==first.Hasta&&r.ListarPagos("30123456").Count==2,"Renovación incorrecta.");});
            test("Apto vencido impide cobrar",()=>{var r=new MemoryRepository();r.Agregar(new Socio("30123456","Ana","Gómez",new DateTime(1990,1,1),today,today));Fails(()=>r.RegistrarPago("30123456",today.AddDays(1),100));});
            test("Actualizar apto vencido rechazado",()=>Fails(()=>member().ActualizarApto(today.AddDays(-1),today)));
            test("Actualizar apto permite cobro posterior",()=>{var r=new MemoryRepository();r.Agregar(new Socio("30123456","Ana","Gómez",new DateTime(1990,1,1),today,today));r.ActualizarApto("30123456",today.AddMonths(2),today.AddDays(1));r.RegistrarPago("30123456",today.AddDays(1),100);});
            test("Reporte incluye socio sin pagos y excluye no socio",()=>{var r=new MemoryRepository();r.Agregar(member());r.Agregar(new NoSocio("32123456","Luis","Pérez",new DateTime(1990,1,1),today,today));var x=r.Vencimientos(today,false);Assert(x.Count==1&&x[0].Estado=="SIN PAGOS","Reporte incorrecto.");});
            test("Reporte exacto y con vencidos anteriores",()=>{var r=new MemoryRepository();r.Agregar(member());var pay=r.RegistrarPago("30123456",today,100);Assert(r.Vencimientos(pay.Hasta,false).Count==1,"Falta vencimiento.");Assert(r.Vencimientos(pay.Hasta.AddDays(1),false).Count==0,"Filtro exacto incorrecto.");Assert(r.Vencimientos(pay.Hasta.AddDays(1),true).Count==1,"Falta vencido.");});
            test("Carnet restringido a socios",()=>{var s=new ClubService(new MemoryRepository(),()=>today);Fails(()=>s.Carnet(new NoSocio("30123456","Ana","Gómez",new DateTime(1990,1,1),today,today)));Assert(s.Carnet(member()).Contains("30123456"),"Falta DNI.");});
            test("Servicio rechaza tipo de persona desconocido",()=>{var s=new ClubService(new MemoryRepository(),()=>today);Fails(()=>s.Inscribir("OTRO","30123456","Ana","Gómez",new DateTime(1990,1,1),today));});
            test("No socio: rechaza segundo pago diario",()=>{var r=new MemoryRepository();r.Agregar(new NoSocio("30123456","Ana","Gómez",new DateTime(1990,1,1),today,today.AddMonths(2)));var p=r.RegistrarPago("30123456",today,100);Assert(p.Tipo=="DIARIA"&&p.Hasta==today.AddDays(1),"Período diario incorrecto.");Fails(()=>r.RegistrarPago("30123456",today,100));r.RegistrarPago("30123456",today.AddDays(1),100);});
            log.AppendLine("\r\nTotal: "+total+". Correctas: "+(total-failed)+". Fallidas: "+failed+".");
            report=log.ToString();return failed==0?0:1;
        }
    }
}
