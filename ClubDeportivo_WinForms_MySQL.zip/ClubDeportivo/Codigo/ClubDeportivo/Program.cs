using System;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace ClubDeportivo
{
    internal static class Program
    {
        [STAThread]
        private static int Main(string[] args)
        {
            if (args.Length > 0 && args[0] == "--autoprueba")
            {
                string report;
                int result = SelfTests.Run(out report);
                if (args.Length > 1) File.WriteAllText(args[1], report, Encoding.UTF8);
                return result;
            }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            if (args.Length > 0 && args[0] == "--demo")
            {
                Application.Run(new MainForm(new ClubService(MemoryRepository.CreateDemo(DateTime.Today),()=>DateTime.Today),true));
                return 0;
            }
            Application.Run(new ConnectionForm());
            return 0;
        }
    }
}
