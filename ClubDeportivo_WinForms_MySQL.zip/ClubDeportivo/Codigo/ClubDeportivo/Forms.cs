using System;
using System.Collections.Generic;
using System.Data.Odbc;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;

namespace ClubDeportivo
{
    internal static class Ui
    {
        public static readonly Color Navy = Color.FromArgb(23,52,78);
        public static readonly Color Teal = Color.FromArgb(0,112,121);
        public static Label Label(string text)
        { return new Label { Text=text, AutoSize=true, Anchor=AnchorStyles.Left, Margin=new Padding(4,8,10,8) }; }
        public static Button Button(string text, EventHandler click)
        {
            var b = new Button { Text=text, AutoSize=true, Height=34, Padding=new Padding(8,3,8,3), Margin=new Padding(5) };
            b.Click += click; return b;
        }
        public static DataGridView Grid()
        {
            return new DataGridView { Dock=DockStyle.Fill, ReadOnly=true, AutoGenerateColumns=false,
                AllowUserToAddRows=false, AllowUserToDeleteRows=false, MultiSelect=false,
                SelectionMode=DataGridViewSelectionMode.FullRowSelect, RowHeadersVisible=false,
                BackgroundColor=Color.White, BorderStyle=BorderStyle.FixedSingle, AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill };
        }
        public static void Column(DataGridView g,string property,string title,string format)
        {
            var c = new DataGridViewTextBoxColumn { DataPropertyName=property, HeaderText=title };
            if(format != null) c.DefaultCellStyle.Format = format;
            g.Columns.Add(c);
        }
        public static void Style(Form f, string title, int width, int height)
        {
            f.Text=title; f.Size=new Size(width,height); f.StartPosition=FormStartPosition.CenterScreen;
            f.Font=new Font("Segoe UI",10); f.BackColor=Color.FromArgb(244,247,249);
            f.AutoScaleMode=AutoScaleMode.Dpi;
        }
        public static void Error(Exception ex)
        {
            string message = ex.Message;
            var db = ex as OdbcException;
            if(db != null)
            {
                var errors = db.Errors.Cast<OdbcError>().ToList();
                var business = errors.FirstOrDefault(e => e.SQLState == "45000");
                if(business != null) message=business.Message;
                else if(errors.Any(e => e.NativeError==1062)) message="Ya existe una persona o un pago con esos datos.";
                else if(errors.Any(e => e.SQLState.StartsWith("IM"))) message="No se encontró el controlador ODBC seleccionado. Instale MySQL Connector/ODBC de 64 bits y vuelva a abrir el programa.";
                else message="No se pudo completar la operación en MySQL. Revise servidor, puerto, credenciales, permisos y script SQL.\r\n\r\nDetalle: " + ex.Message;
            }
            MessageBox.Show(message,"Revisar datos",MessageBoxButtons.OK,MessageBoxIcon.Warning);
        }
        public static void Document(Form owner,string title,string text)
        {
            using(var f=new Form())
            {
                Style(f,title,680,500); f.MinimumSize=new Size(520,400);
                var box=new TextBox { Multiline=true,ReadOnly=true,Dock=DockStyle.Fill,ScrollBars=ScrollBars.Both,
                    Font=new Font("Consolas",11),Text=text,BackColor=Color.White,WordWrap=true };
                var actions=new FlowLayoutPanel { Dock=DockStyle.Bottom,Height=54 };
                actions.Controls.Add(Button("Guardar texto",delegate {
                    using(var save=new SaveFileDialog { Filter="Documento de texto (*.txt)|*.txt",FileName=title.Replace(" ","_")+".txt" })
                        if(save.ShowDialog(f)==DialogResult.OK)
                            try { File.WriteAllText(save.FileName,text,Encoding.UTF8); }
                            catch(Exception ex) { Error(ex); }
                }));
                actions.Controls.Add(Button("Imprimir",delegate {
                    try {
                        using(var doc=new PrintDocument())
                        using(var dialog=new PrintDialog { Document=doc, UseEXDialog=true })
                        {
                            doc.PrintPage += delegate(object sender, PrintPageEventArgs e) {
                                using(var font=new Font("Segoe UI",12))
                                    e.Graphics.DrawString(text,font,Brushes.Black,e.MarginBounds);
                            };
                            if(dialog.ShowDialog(f)==DialogResult.OK) doc.Print();
                        }
                    } catch(Exception ex) { Error(ex); }
                }));
                f.Controls.Add(box); f.Controls.Add(actions); f.ShowDialog(owner);
            }
        }
    }

    public sealed class ConnectionForm : Form
    {
        private readonly ComboBox driver = new ComboBox { DropDownStyle=ComboBoxStyle.DropDownList,Dock=DockStyle.Fill };
        private readonly TextBox server = new TextBox { Text="localhost",Dock=DockStyle.Fill };
        private readonly NumericUpDown port = new NumericUpDown { Minimum=1,Maximum=65535,Value=3306,Dock=DockStyle.Fill };
        private readonly TextBox database = new TextBox { Text="club_deportivo_pif",Dock=DockStyle.Fill };
        private readonly TextBox user = new TextBox { Dock=DockStyle.Fill };
        private readonly TextBox password = new TextBox { UseSystemPasswordChar=true,Dock=DockStyle.Fill };
        private readonly Button connect;
        private readonly Label status=Ui.Label("");
        public ConnectionForm()
        {
            Ui.Style(this,"Club Deportivo | Conexión a MySQL",640,600);
            MinimumSize=new Size(620,580);
            var layout=new TableLayoutPanel { Dock=DockStyle.Fill,Padding=new Padding(24),ColumnCount=2,AutoScroll=true };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,165));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
            var title=Ui.Label("CLUB DEPORTIVO"); title.Font=new Font(Font,FontStyle.Bold); title.ForeColor=Ui.Navy;
            layout.Controls.Add(title,0,0); layout.SetColumnSpan(title,2);
            var help=Ui.Label("Ingrese los datos del servidor. La contraseña no se guarda en archivos.");
            help.MaximumSize=new Size(540,0); layout.Controls.Add(help,0,1);layout.SetColumnSpan(help,2);
            Add(layout,2,"Controlador ODBC",driver); Add(layout,3,"Servidor",server); Add(layout,4,"Puerto",port);
            Add(layout,5,"Base de datos",database); Add(layout,6,"Usuario MySQL",user); Add(layout,7,"Contraseña",password);
            connect=Ui.Button("Conectar e ingresar",Connect);
            layout.Controls.Add(connect,1,8); AcceptButton=connect;
            status.MaximumSize=new Size(535,0);layout.Controls.Add(status,0,9);layout.SetColumnSpan(status,2);
            var note=Ui.Label("Antes de ingresar: importe DB/club_deportivo.sql y tenga MySQL Connector/ODBC x64 instalado. Consulte LEEME.md.");
            note.MaximumSize=new Size(535,0);layout.Controls.Add(note,0,10);layout.SetColumnSpan(note,2);
            Controls.Add(layout); LoadDrivers();
        }
        private static void Add(TableLayoutPanel panel,int row,string label,Control control)
        { panel.Controls.Add(Ui.Label(label),0,row);panel.Controls.Add(control,1,row);control.Margin=new Padding(4,8,4,8); }
        private void LoadDrivers()
        {
            try {
                using(var root=RegistryKey.OpenBaseKey(RegistryHive.LocalMachine,RegistryView.Registry64))
                using(var key=root.OpenSubKey(@"SOFTWARE\ODBC\ODBCINST.INI\ODBC Drivers"))
                    if(key!=null)
                        foreach(var name in key.GetValueNames().Where(n=>n.IndexOf("MySQL",StringComparison.OrdinalIgnoreCase)>=0)
                            .OrderBy(n=>n.IndexOf("Unicode",StringComparison.OrdinalIgnoreCase)<0?1:0).ThenBy(n=>n))
                            driver.Items.Add(name);
                if(driver.Items.Count>0) driver.SelectedIndex=0;
                else { connect.Enabled=false;status.Text="No se detectó un controlador MySQL ODBC x64. Instálelo y vuelva a abrir el programa."; }
            } catch(Exception ex) { connect.Enabled=false;status.Text="No se pudieron consultar los controladores: "+ex.Message; }
        }
        private async void Connect(object sender,EventArgs e)
        {
            if(String.IsNullOrWhiteSpace(server.Text)||String.IsNullOrWhiteSpace(database.Text)||String.IsNullOrWhiteSpace(user.Text))
            { Ui.Error(new ArgumentException("Complete servidor, base de datos y usuario."));return; }
            connect.Enabled=false;status.Text="Conectando…";
            try {
                var builder=new OdbcConnectionStringBuilder();
                builder.Driver=Convert.ToString(driver.SelectedItem);
                builder["SERVER"]=server.Text.Trim();builder["PORT"]=(int)port.Value;
                builder["DATABASE"]=database.Text.Trim();builder["UID"]=user.Text.Trim();builder["PWD"]=password.Text;
                var repository=new MySqlRepository(builder.ConnectionString);
                await Task.Run(()=>repository.ProbarConexion());
                password.Clear();status.Text="Conexión establecida.";
                Hide();
                using(var main=new MainForm(new ClubService(repository,()=>DateTime.Today))) main.ShowDialog();
                Close();
            } catch(Exception ex) { status.Text="No se pudo ingresar.";Ui.Error(ex); }
            finally { connect.Enabled=true; }
        }
    }

    public sealed class MainForm : Form
    {
        private readonly ClubService service;
        private readonly TabControl tabs=new TabControl { Dock=DockStyle.Fill };
        private readonly DataGridView people=Ui.Grid(),payments=Ui.Grid(),dues=Ui.Grid();
        private readonly TextBox search=new TextBox { Width=240 };
        private readonly TextBox dni=new TextBox { MaxLength=9,Width=125 }, name=new TextBox { MaxLength=80,Width=170 }, surname=new TextBox { MaxLength=80,Width=170 };
        private readonly ComboBox type=new ComboBox { DropDownStyle=ComboBoxStyle.DropDownList,Width=130 };
        private readonly DateTimePicker birth=new DateTimePicker { Format=DateTimePickerFormat.Short,Width=130,Value=DateTime.Today.AddYears(-18),MaxDate=DateTime.Today.AddDays(-1) };
        private readonly DateTimePicker apt=new DateTimePicker { Format=DateTimePickerFormat.Short,Width=130,Value=DateTime.Today.AddYears(1) };
        private readonly DateTimePicker renew=new DateTimePicker { Format=DateTimePickerFormat.Short,Width=130,Value=DateTime.Today.AddYears(1) };
        private readonly CheckBox certificate=new CheckBox { Text="Apto físico presentado y verificado",AutoSize=true };
        private readonly ComboBox payPerson=new ComboBox { DropDownStyle=ComboBoxStyle.DropDownList,Width=390 };
        private readonly NumericUpDown amount=new NumericUpDown { DecimalPlaces=2,Minimum=0,Maximum=99999999.99m,ThousandsSeparator=true,Width=150 };
        private readonly DateTimePicker reportDate=new DateTimePicker { Format=DateTimePickerFormat.Short,Width=130 };
        private readonly CheckBox overdue=new CheckBox { Text="Incluir vencimientos anteriores",AutoSize=true };
        private readonly Label state=Ui.Label("Seleccione una opción del menú.");
        private IList<Persona> all=new List<Persona>();
        public MainForm(ClubService service, bool demo = false)
        {
            this.service=service;Ui.Style(this,"Club Deportivo | Gestión",1180,800);MinimumSize=new Size(1080,740);
            if(demo) Text="Club Deportivo | DEMOSTRACIÓN SIN MYSQL";
            var header=new Label { Text=demo?"DEMOSTRACIÓN | Datos ficticios en memoria; no se guardan":"CLUB DEPORTIVO  |  Socios, pagos y vencimientos",Dock=DockStyle.Top,Height=60,
                ForeColor=Color.White,BackColor=Ui.Navy,Font=new Font("Segoe UI",16,FontStyle.Bold),TextAlign=ContentAlignment.MiddleLeft,Padding=new Padding(18,0,0,0) };
            var footer=new Panel { Dock=DockStyle.Bottom,Height=34 };footer.Controls.Add(state);
            Controls.Add(tabs);Controls.Add(footer);Controls.Add(header);
            BuildPeople();BuildPayments();BuildDues();
            Shown += delegate { RefreshPeople(null); };
        }
        private async void Run<T>(Func<T> work, Action<T> success)
        {
            tabs.Enabled=false;UseWaitCursor=true;state.Text="Procesando…";
            try { T result=await Task.Run(work);state.Text="Operación completada.";success(result); }
            catch(Exception ex) {state.Text="La operación no se completó.";Ui.Error(ex);}
            finally {UseWaitCursor=false;tabs.Enabled=true;}
        }
        private static FlowLayoutPanel Row(int height)
        { return new FlowLayoutPanel { Dock=DockStyle.Fill,AutoSize=false,Height=height,Padding=new Padding(5),WrapContents=true }; }
        private static TableLayoutPanel PageLayout(TabPage tab, params float[] heights)
        {
            var p=new TableLayoutPanel { Dock=DockStyle.Fill,ColumnCount=1,RowCount=heights.Length,Padding=new Padding(10) };
            p.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
            foreach(var h in heights) p.RowStyles.Add(new RowStyle(h<0?SizeType.Percent:SizeType.Absolute,Math.Abs(h)));
            tab.Controls.Add(p);return p;
        }
        private void BuildPeople()
        {
            var tab=new TabPage("Personas y carnet");tabs.TabPages.Add(tab);
            var layout=PageLayout(tab,52,-100,35,52,52,52,60,62);
            var filter=Row(52);filter.Controls.Add(Ui.Label("Buscar DNI o apellido"));filter.Controls.Add(search);
            filter.Controls.Add(Ui.Button("Actualizar",delegate{RefreshPeople(null);}));
            layout.Controls.Add(filter,0,0);layout.Controls.Add(people,0,1);
            Ui.Column(people,"Dni","DNI",null);Ui.Column(people,"Apellido","Apellido",null);Ui.Column(people,"Nombre","Nombre",null);
            Ui.Column(people,"Tipo","Tipo",null);Ui.Column(people,"Alta","Alta","dd/MM/yyyy");Ui.Column(people,"AptoHasta","Apto hasta","dd/MM/yyyy");
            search.TextChanged += delegate {FilterPeople();};
            layout.Controls.Add(Ui.Label("NUEVA INSCRIPCIÓN"),0,2);
            type.Items.AddRange(new object[]{"SOCIO","NO_SOCIO"});type.SelectedIndex=0;
            var r1=Row(52);r1.Controls.Add(Ui.Label("Tipo"));r1.Controls.Add(type);r1.Controls.Add(Ui.Label("DNI"));r1.Controls.Add(dni);
            r1.Controls.Add(Ui.Label("Nacimiento"));r1.Controls.Add(birth);layout.Controls.Add(r1,0,3);
            var r2=Row(52);r2.Controls.Add(Ui.Label("Nombre"));r2.Controls.Add(name);r2.Controls.Add(Ui.Label("Apellido"));r2.Controls.Add(surname);layout.Controls.Add(r2,0,4);
            var r3=Row(52);r3.Controls.Add(Ui.Label("Apto válido hasta"));r3.Controls.Add(apt);r3.Controls.Add(certificate);layout.Controls.Add(r3,0,5);
            var r4=Row(60);r4.Controls.Add(Ui.Button("Registrar persona",delegate {
                if(!certificate.Checked) {Ui.Error(new ArgumentException("Verifique la presentación del apto físico antes de inscribir."));return;}
                string t=Convert.ToString(type.SelectedItem),d=dni.Text,n=name.Text,a=surname.Text;DateTime b=birth.Value,f=apt.Value;
                Run(()=>{service.Inscribir(t,d,n,a,b,f);return service.Personas();},result=>{
                    all=result;BindPeople();dni.Clear();name.Clear();surname.Clear();certificate.Checked=false;
                    MessageBox.Show("Persona registrada correctamente.","Inscripción");
                });
            }));
            r4.Controls.Add(Ui.Label("El DNI identifica de forma única a socios y no socios."));layout.Controls.Add(r4,0,6);
            var r5=Row(62);r5.Controls.Add(Ui.Label("Persona seleccionada: apto hasta"));r5.Controls.Add(renew);
            r5.Controls.Add(Ui.Button("Actualizar apto",delegate {
                var p=Selected();if(p==null)return;DateTime hasta=renew.Value;
                Run(()=>{service.RenovarApto(p.Dni,hasta);return service.Personas();},result=>{all=result;BindPeople();});
            }));
            r5.Controls.Add(Ui.Button("Emitir carnet",delegate {
                var p=Selected();if(p==null)return;
                try {Ui.Document(this,"Carnet_"+p.Dni,service.Carnet(p));}catch(Exception ex){Ui.Error(ex);}
            }));layout.Controls.Add(r5,0,7);
        }
        private void FilterPeople()
        {
            string value=search.Text.Trim();
            people.DataSource=all.Where(p=>p.Dni.Contains(value)||p.Apellido.IndexOf(value,StringComparison.CurrentCultureIgnoreCase)>=0).ToList();
        }
        private void BindPeople()
        {
            FilterPeople();string previous=(payPerson.SelectedItem as PersonChoice)==null?null:((PersonChoice)payPerson.SelectedItem).Person.Dni;
            payPerson.Items.Clear();foreach(var p in all)payPerson.Items.Add(new PersonChoice(p));
            for(int i=0;i<payPerson.Items.Count;i++)if(((PersonChoice)payPerson.Items[i]).Person.Dni==previous)payPerson.SelectedIndex=i;
            payments.DataSource=null;
            state.Text=all.Count+" personas registradas.";
        }
        private void RefreshPeople(Action after)
        {Run(()=>service.Personas(),result=>{all=result;BindPeople();if(after!=null)after();});}
        private Persona Selected()
        {
            var p=people.CurrentRow==null?null:people.CurrentRow.DataBoundItem as Persona;
            if(p==null)Ui.Error(new ArgumentException("Seleccione una persona en el listado."));return p;
        }
        private sealed class PersonChoice
        {
            public Persona Person;
            public PersonChoice(Persona p){Person=p;}
            public override string ToString(){return Person.Apellido+", "+Person.Nombre+" | "+Person.Dni+" | "+Person.Tipo;}
        }
        private void BuildPayments()
        {
            var tab=new TabPage("Pagos y comprobantes");tabs.TabPages.Add(tab);
            var layout=PageLayout(tab,65,62,54,-100);
            var r1=Row(65);r1.Controls.Add(Ui.Label("Persona"));r1.Controls.Add(payPerson);
            r1.Controls.Add(Ui.Button("Ver historial",delegate {LoadPayments();}));layout.Controls.Add(r1,0,0);
            payPerson.SelectedIndexChanged += delegate {payments.DataSource=null;};
            var r2=Row(62);r2.Controls.Add(Ui.Label("Importe en pesos"));r2.Controls.Add(amount);
            r2.Controls.Add(Ui.Button("Registrar pago",delegate {
                var selected=payPerson.SelectedItem as PersonChoice;
                if(selected==null){Ui.Error(new ArgumentException("Seleccione una persona."));return;}
                var p=selected.Person;decimal value=amount.Value;
                if(value<=0){Ui.Error(new ArgumentException("Ingrese el importe de la cuota acordada."));return;}
                if(MessageBox.Show("Registrar cuota "+p.TipoPago+" para "+p.Apellido+", "+p.Nombre+" por $ "+value.ToString("N2")+"?",
                    "Confirmar cobro",MessageBoxButtons.YesNo,MessageBoxIcon.Question)!=DialogResult.Yes)return;
                Run(()=>service.Cobrar(p.Dni,value),pago=>{
                    payments.DataSource=null;
                    Ui.Document(this,"Comprobante_"+pago.Id,Receipt(pago,p));
                    state.Text="Pago registrado. Pulse Ver historial para actualizar el listado.";
                });
            }));
            r2.Controls.Add(Ui.Button("Ver comprobante",delegate {
                var row=payments.CurrentRow==null?null:payments.CurrentRow.DataBoundItem as Pago;
                var person=payPerson.SelectedItem as PersonChoice;
                if(row==null||person==null){Ui.Error(new ArgumentException("Seleccione un pago del historial."));return;}
                Ui.Document(this,"Comprobante_"+row.Id,Receipt(row,person.Person));
            }));layout.Controls.Add(r2,0,1);
            var note=Ui.Label("Socios: cuota mensual. No socios: cuota diaria. No se admite otro cobro mientras exista un período vigente. El importe se ingresa según la tarifa del club.");
            note.MaximumSize=new Size(1000,0);layout.Controls.Add(note,0,2);layout.Controls.Add(payments,0,3);
            Ui.Column(payments,"Id","Nro.",null);Ui.Column(payments,"Tipo","Cuota",null);Ui.Column(payments,"Fecha","Pago","dd/MM/yyyy");
            Ui.Column(payments,"Desde","Desde","dd/MM/yyyy");Ui.Column(payments,"Hasta","Vence (exclusivo)","dd/MM/yyyy");Ui.Column(payments,"Importe","Importe ($)","N2");
        }
        private void LoadPayments()
        {
            var selected=payPerson.SelectedItem as PersonChoice;
            if(selected==null){Ui.Error(new ArgumentException("Seleccione una persona."));return;}
            string id=selected.Person.Dni;Run(()=>service.Pagos(id),result=>{payments.DataSource=result;});
        }
        private static string Receipt(Pago p,Persona person)
        {
            return "CLUB DEPORTIVO\r\nCOMPROBANTE INTERNO DE PAGO Nro. "+p.Id+"\r\n\r\n"+
                person.Apellido+", "+person.Nombre+"\r\nDNI: "+p.Dni+"\r\nCuota: "+p.Tipo+
                "\r\nFecha de pago: "+p.Fecha.ToString("dd/MM/yyyy")+"\r\nImporte: $ "+p.Importe.ToString("N2")+
                "\r\nDesde: "+p.Desde.ToString("dd/MM/yyyy")+"\r\nVencimiento: "+p.Hasta.ToString("dd/MM/yyyy")+
                " (exclusivo)\r\n\r\nEl período cubre hasta el día anterior al vencimiento.\r\nComprobante interno educativo; no es factura fiscal.";
        }
        private void BuildDues()
        {
            var tab=new TabPage("Vencimientos de socios");tabs.TabPages.Add(tab);
            var layout=PageLayout(tab,68,54,-100);
            var row=Row(68);row.Controls.Add(Ui.Label("Fecha"));row.Controls.Add(reportDate);row.Controls.Add(overdue);
            row.Controls.Add(Ui.Button("Consultar",delegate {
                DateTime date=reportDate.Value;bool previous=overdue.Checked;
                Run(()=>service.Vencimientos(date,previous),result=>{dues.DataSource=result;state.Text=result.Count+" socios en el resultado.";});
            }));layout.Controls.Add(row,0,0);
            var note=Ui.Label("Sin pagos: se toma la fecha de alta como primer vencimiento. La consulta considera el último pago registrado; no reconstruye estados históricos.");
            note.MaximumSize=new Size(1000,0);layout.Controls.Add(note,0,1);layout.Controls.Add(dues,0,2);
            Ui.Column(dues,"Dni","DNI",null);Ui.Column(dues,"Apellido","Apellido",null);Ui.Column(dues,"Nombre","Nombre",null);
            Ui.Column(dues,"Fecha","Vencimiento","dd/MM/yyyy");Ui.Column(dues,"Estado","Estado",null);
        }
    }
}
