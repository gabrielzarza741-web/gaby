using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Odbc;
using System.Globalization;

namespace ClubDeportivo
{
    // ADO.NET ODBC: utiliza el controlador oficial MySQL Connector/ODBC de Windows.
    public sealed class MySqlRepository : IClubRepository
    {
        private readonly string connectionString;
        public MySqlRepository(string connectionString) { this.connectionString = connectionString; }
        public void ProbarConexion()
        {
            using (var con = Open())
            using (var cmd = new OdbcCommand("SELECT COUNT(*) FROM configuracion WHERE clave='schema_version' AND valor='1'", con))
            {
                if (Convert.ToInt32(cmd.ExecuteScalar()) != 1)
                    throw new InvalidOperationException("La base no corresponde a este proyecto. Importe DB/club_deportivo.sql.");
            }
        }
        private OdbcConnection Open()
        {
            var con = new OdbcConnection(connectionString);
            try { con.Open(); return con; }
            catch { con.Dispose(); throw; }
        }
        private static OdbcCommand Call(OdbcConnection con, string sql, params object[] values)
        {
            var cmd = new OdbcCommand(sql, con); cmd.CommandTimeout = 15;
            foreach (var value in values)
            {
                OdbcParameter p;
                if (value is DateTime) p = new OdbcParameter("", OdbcType.Date) { Value = ((DateTime)value).Date };
                else if (value is decimal) p = new OdbcParameter("", OdbcType.Decimal) { Precision = 10, Scale = 2, Value = value };
                else if (value is int) p = new OdbcParameter("", OdbcType.Int) { Value = value };
                else p = new OdbcParameter("", OdbcType.NVarChar, Math.Max(1, Convert.ToString(value).Length)) { Value = value };
                cmd.Parameters.Add(p);
            }
            return cmd;
        }
        private static string Text(IDataRecord r, string name) { return Convert.ToString(r[name]); }
        private static DateTime Date(IDataRecord r, string name) { return Convert.ToDateTime(r[name]); }
        public IList<Persona> ListarPersonas()
        {
            var list = new List<Persona>();
            using (var con = Open())
            using (var cmd = Call(con, "CALL sp_listar_personas()"))
            using (var r = cmd.ExecuteReader())
                while (r.Read())
                {
                    Persona p = Text(r,"tipo") == "SOCIO"
                        ? (Persona)new Socio(Text(r,"dni"),Text(r,"nombre"),Text(r,"apellido"),Date(r,"nacimiento"),Date(r,"alta"),Date(r,"apto_hasta"))
                        : new NoSocio(Text(r,"dni"),Text(r,"nombre"),Text(r,"apellido"),Date(r,"nacimiento"),Date(r,"alta"),Date(r,"apto_hasta"));
                    list.Add(p);
                }
            return list;
        }
        public void Agregar(Persona p)
        {
            using (var con = Open())
            using (var cmd = Call(con,"CALL sp_registrar_persona(?,?,?,?,?,?,?)",p.Dni,p.Nombre,p.Apellido,p.Tipo,p.Nacimiento,p.Alta,p.AptoHasta))
                cmd.ExecuteNonQuery();
        }
        public void ActualizarApto(string dni, DateTime hasta, DateTime hoy)
        {
            using (var con = Open())
            using (var cmd = Call(con,"CALL sp_actualizar_apto(?,?,?)",dni,hasta,hoy)) cmd.ExecuteNonQuery();
        }
        public IList<Pago> ListarPagos(string dni)
        {
            var list = new List<Pago>();
            using (var con = Open())
            using (var cmd = Call(con,"CALL sp_listar_pagos(?)",dni))
            using (var r = cmd.ExecuteReader())
                while (r.Read()) list.Add(Pago.DesdeRegistro(Convert.ToInt64(r["id"]),Text(r,"dni"),Text(r,"tipo"),Date(r,"fecha"),Date(r,"desde"),Date(r,"hasta"),Convert.ToDecimal(r["importe"])));
            return list;
        }
        public Pago RegistrarPago(string dni, DateTime fecha, decimal importe)
        {
            // El procedimiento decide el período y bloquea la persona durante el cobro.
            using (var con = Open())
            using (var cmd = Call(con,"CALL sp_registrar_pago(?,?,?)",dni,fecha,importe))
            using (var r = cmd.ExecuteReader())
            {
                if (!r.Read()) throw new InvalidOperationException("La base no devolvió el comprobante del pago.");
                return Pago.DesdeRegistro(Convert.ToInt64(r["id"]),Text(r,"dni"),Text(r,"tipo"),Date(r,"fecha"),Date(r,"desde"),Date(r,"hasta"),Convert.ToDecimal(r["importe"]));
            }
        }
        public IList<Vencimiento> Vencimientos(DateTime fecha, bool anteriores)
        {
            var list = new List<Vencimiento>();
            using (var con = Open())
            using (var cmd = Call(con,"CALL sp_vencimientos(?,?)",fecha,anteriores ? 1 : 0))
            using (var r = cmd.ExecuteReader())
                while (r.Read()) list.Add(new Vencimiento { Dni=Text(r,"dni"),Nombre=Text(r,"nombre"),Apellido=Text(r,"apellido"),Fecha=Date(r,"vencimiento"),Estado=Text(r,"estado") });
            return list;
        }
    }
}
