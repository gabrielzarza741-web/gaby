@echo off
start "" "%~dp0Ejecutable\Release\ClubDeportivo.exe" --demo
