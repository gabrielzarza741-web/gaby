-- Proyecto educativo. MySQL 8.0.16 o posterior, motor InnoDB.
-- No elimina tablas ni datos. Reejecutar reemplaza los procedimientos de este proyecto.
CREATE DATABASE IF NOT EXISTS club_deportivo_pif CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE club_deportivo_pif;

CREATE TABLE IF NOT EXISTS configuracion (
    clave VARCHAR(50) PRIMARY KEY,
    valor VARCHAR(100) NOT NULL
) ENGINE=InnoDB;
INSERT IGNORE INTO configuracion(clave,valor) VALUES ('schema_version','1');

CREATE TABLE IF NOT EXISTS personas (
    dni VARCHAR(9) PRIMARY KEY,
    nombre VARCHAR(80) NOT NULL,
    apellido VARCHAR(80) NOT NULL,
    tipo ENUM('SOCIO','NO_SOCIO') NOT NULL,
    nacimiento DATE NOT NULL,
    alta DATE NOT NULL,
    apto_hasta DATE NOT NULL,
    CONSTRAINT ck_nacimiento CHECK (nacimiento < alta),
    CONSTRAINT ck_apto_inicial CHECK (apto_hasta >= alta)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS pagos (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    dni VARCHAR(9) NOT NULL,
    tipo ENUM('MENSUAL','DIARIA') NOT NULL,
    fecha DATE NOT NULL,
    desde DATE NOT NULL,
    hasta DATE NOT NULL,
    importe DECIMAL(10,2) NOT NULL,
    CONSTRAINT fk_pago_persona FOREIGN KEY (dni) REFERENCES personas(dni),
    CONSTRAINT uq_pago_periodo UNIQUE (dni,tipo,desde),
    CONSTRAINT ck_importe CHECK (importe > 0),
    CONSTRAINT ck_periodo CHECK (hasta > desde),
    INDEX ix_pagos_vencimiento(dni,hasta)
) ENGINE=InnoDB;

-- No se cargan personas ficticias en la base operativa.
-- La única fila previa obligatoria es la versión del esquema.
DELIMITER $$

DROP PROCEDURE IF EXISTS sp_registrar_persona$$
CREATE PROCEDURE sp_registrar_persona(
    IN p_dni VARCHAR(32), IN p_nombre VARCHAR(255), IN p_apellido VARCHAR(255),
    IN p_tipo VARCHAR(20), IN p_nacimiento DATE, IN p_alta DATE, IN p_apto DATE)
BEGIN
    DECLARE EXIT HANDLER FOR 1062
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Ya existe una persona con ese DNI.';
    IF p_dni IS NULL OR p_dni NOT REGEXP '^[0-9]{7,9}$' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='DNI invalido: debe tener entre 7 y 9 digitos.';
    END IF;
    IF p_nombre IS NULL OR p_apellido IS NULL OR CHAR_LENGTH(TRIM(p_nombre)) NOT BETWEEN 1 AND 80
       OR CHAR_LENGTH(TRIM(p_apellido)) NOT BETWEEN 1 AND 80 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Complete nombre y apellido (hasta 80 caracteres).';
    END IF;
    IF p_tipo IS NULL OR p_tipo NOT IN ('SOCIO','NO_SOCIO') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Tipo de persona invalido.';
    END IF;
    IF p_alta IS NULL OR p_nacimiento IS NULL OR p_nacimiento >= p_alta
       OR p_nacimiento < DATE_SUB(p_alta, INTERVAL 120 YEAR) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Fecha de nacimiento invalida.';
    END IF;
    IF p_apto IS NULL OR p_apto < p_alta THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Se requiere apto fisico vigente para inscribirse.';
    END IF;
    INSERT INTO personas VALUES(p_dni,TRIM(p_nombre),TRIM(p_apellido),p_tipo,p_nacimiento,p_alta,p_apto);
END$$

DROP PROCEDURE IF EXISTS sp_listar_personas$$
CREATE PROCEDURE sp_listar_personas()
BEGIN
    SELECT dni,nombre,apellido,tipo,nacimiento,alta,apto_hasta FROM personas ORDER BY apellido,nombre,dni;
END$$

DROP PROCEDURE IF EXISTS sp_actualizar_apto$$
CREATE PROCEDURE sp_actualizar_apto(IN p_dni VARCHAR(9), IN p_hasta DATE, IN p_hoy DATE)
BEGIN
    IF p_hasta IS NULL OR p_hoy IS NULL OR p_hasta < p_hoy THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='El apto fisico debe estar vigente.';
    END IF;
    IF NOT EXISTS(SELECT 1 FROM personas WHERE dni=p_dni) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Persona no encontrada.';
    END IF;
    UPDATE personas SET apto_hasta=p_hasta WHERE dni=p_dni;
END$$

DROP PROCEDURE IF EXISTS sp_listar_pagos$$
CREATE PROCEDURE sp_listar_pagos(IN p_dni VARCHAR(9))
BEGIN
    SELECT id,dni,tipo,fecha,desde,hasta,importe FROM pagos WHERE dni=p_dni ORDER BY id DESC;
END$$

DROP PROCEDURE IF EXISTS sp_registrar_pago$$
CREATE PROCEDURE sp_registrar_pago(IN p_dni VARCHAR(9), IN p_fecha DATE, IN p_importe DECIMAL(10,2))
BEGIN
    DECLARE v_tipo VARCHAR(20) DEFAULT NULL;
    DECLARE v_apto DATE;
    DECLARE v_alta DATE;
    DECLARE v_ultimo DATE;
    DECLARE v_hasta DATE;
    DECLARE v_id BIGINT;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    IF p_fecha IS NULL OR p_importe IS NULL OR p_importe <= 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Fecha o importe de pago invalido.';
    END IF;
    START TRANSACTION;
    -- Bloqueo por persona: evita dos cobros simultaneos para el mismo periodo.
    SELECT tipo,apto_hasta,alta INTO v_tipo,v_apto,v_alta FROM personas WHERE dni=p_dni FOR UPDATE;
    IF v_tipo IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Persona no encontrada.';
    END IF;
    IF p_fecha < v_alta THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='El pago no puede ser anterior al alta.';
    END IF;
    IF v_apto < p_fecha THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Renueve el apto fisico antes de registrar un pago.';
    END IF;
    SELECT MAX(hasta) INTO v_ultimo FROM pagos WHERE dni=p_dni;
    IF v_ultimo IS NOT NULL AND v_ultimo > p_fecha THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='La persona ya tiene un periodo pago vigente.';
    END IF;
    IF v_tipo='SOCIO' THEN
        SET v_hasta=DATE_ADD(p_fecha, INTERVAL 1 MONTH);
    ELSE
        SET v_hasta=DATE_ADD(p_fecha, INTERVAL 1 DAY);
    END IF;
    INSERT INTO pagos(dni,tipo,fecha,desde,hasta,importe)
        VALUES(p_dni,IF(v_tipo='SOCIO','MENSUAL','DIARIA'),p_fecha,p_fecha,v_hasta,p_importe);
    SET v_id=LAST_INSERT_ID();
    COMMIT;
    SELECT id,dni,tipo,fecha,desde,hasta,importe,v_tipo AS tipo_persona FROM pagos WHERE id=v_id;
END$$

DROP PROCEDURE IF EXISTS sp_vencimientos$$
CREATE PROCEDURE sp_vencimientos(IN p_fecha DATE, IN p_incluir_anteriores INT)
BEGIN
    SELECT x.dni,x.nombre,x.apellido,x.vencimiento,
        IF(x.ultimo IS NULL,'SIN PAGOS',IF(x.vencimiento=p_fecha,'VENCE EN LA FECHA','VENCIDA')) AS estado
    FROM (
        SELECT p.dni,p.nombre,p.apellido,p.alta,MAX(g.hasta) AS ultimo,
               COALESCE(MAX(g.hasta),p.alta) AS vencimiento
        FROM personas p LEFT JOIN pagos g ON g.dni=p.dni
        WHERE p.tipo='SOCIO' AND p.alta<=p_fecha
        GROUP BY p.dni,p.nombre,p.apellido,p.alta
    ) AS x
    WHERE (p_incluir_anteriores=0 AND x.vencimiento=p_fecha)
       OR (p_incluir_anteriores=1 AND x.vencimiento<=p_fecha)
    ORDER BY x.vencimiento,x.apellido,x.nombre;
END$$

DELIMITER ;
