$ErrorActionPreference = 'Stop'
$compilerPath = Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319/csc.exe'
if (-not (Test-Path -LiteralPath $compilerPath)) { throw 'Se requiere .NET Framework en Windows de 64 bits.' }
$sourceDir = Join-Path $PSScriptRoot 'Codigo/ClubDeportivo'
$releaseDir = Join-Path $PSScriptRoot 'Ejecutable/Release'
New-Item -ItemType Directory -Force -Path $releaseDir | Out-Null
$executablePath = Join-Path $releaseDir 'ClubDeportivo.exe'
$sourceFiles = Get-ChildItem -LiteralPath $sourceDir -Filter '*.cs' | Select-Object -ExpandProperty FullName
& $compilerPath /nologo /target:winexe /platform:x64 /optimize+ /warn:4 "/out:$executablePath" /reference:System.dll /reference:System.Core.dll /reference:System.Data.dll /reference:System.Drawing.dll /reference:System.Windows.Forms.dll /reference:System.Xml.dll $sourceFiles
if ($LASTEXITCODE -ne 0) { throw 'La compilación falló.' }
Copy-Item -LiteralPath (Join-Path $sourceDir 'App.config') -Destination ($executablePath + '.config') -Force
Write-Output "Compilación correcta: $executablePath"
