$ErrorActionPreference = 'Stop'
$exePath = Join-Path $PSScriptRoot 'Ejecutable/Release/ClubDeportivo.exe'
$reportPath = Join-Path $PSScriptRoot 'Pruebas/resultado-pruebas.txt'
New-Item -ItemType Directory -Force -Path (Split-Path -Parent $reportPath) | Out-Null
$testProcess = Start-Process -FilePath $exePath -ArgumentList @('--autoprueba',('"' + $reportPath + '"')) -Wait -PassThru -WindowStyle Hidden
Get-Content -LiteralPath $reportPath
if ($testProcess.ExitCode -ne 0) { throw 'Hay pruebas fallidas.' }
