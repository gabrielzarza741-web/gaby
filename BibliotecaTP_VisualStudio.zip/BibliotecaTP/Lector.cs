public class Lector
{
    public string Nombre { get; set; }
    public string Dni { get; set; }
    public List<Libro> LibrosPrestados { get; } = new();

    public Lector(string nombre, string dni)
    {
        Nombre = nombre;
        Dni = dni;
    }
}