using System.Linq;

public class Biblioteca
{
    public List<Libro> LibrosDisponibles { get; } = new();
    public List<Lector> Lectores { get; } = new();

    public bool altaLector(string nombre, string dni)
    {
        if (Lectores.Any(l => l.Dni == dni))
            return false;

        Lectores.Add(new Lector(nombre, dni));
        return true;
    }

    public string prestarLibro(string titulo, string dni)
    {
        Lector? lector = Lectores.FirstOrDefault(l => l.Dni == dni);
        if (lector == null)
            return "LECTOR INEXISTENTE";

        Libro? libro = LibrosDisponibles.FirstOrDefault(l => l.Titulo == titulo);
        if (libro == null)
            return "LIBRO INEXISTENTE";

        if (lector.LibrosPrestados.Count >= 3)
            return "TOPE DE PRESTAMO ALCAZADO";

        LibrosDisponibles.Remove(libro);
        lector.LibrosPrestados.Add(libro);
        return "PRESTAMO EXITOSO";
    }
}