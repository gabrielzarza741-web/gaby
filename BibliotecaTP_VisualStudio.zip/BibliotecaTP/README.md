# Trabajo práctico - Biblioteca
Proyecto de consola en C# (.NET 8).

## Ejecución
Abrir BibliotecaTP.csproj en Visual Studio 2022 con soporte para .NET 8 o ejecutar `dotnet run` en esta carpeta.

## Reglas
- No se registra dos veces un mismo DNI.
- Un lector puede tener como máximo tres libros prestados.
- Un préstamo exitoso mueve el libro de LibrosDisponibles a LibrosPrestados.
- Los mensajes de retorno respetan literalmente la consigna (incluido ALCAZADO).

## UML
Ver el PDF adjunto para el diagrama de clases y la explicación.
