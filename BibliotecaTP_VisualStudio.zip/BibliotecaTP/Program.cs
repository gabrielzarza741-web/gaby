Biblioteca biblioteca = new();

biblioteca.LibrosDisponibles.Add(new Libro("El Principito", "Saint-Exupery"));
biblioteca.LibrosDisponibles.Add(new Libro("Don Quijote", "Cervantes"));
biblioteca.LibrosDisponibles.Add(new Libro("Martin Fierro", "Jose Hernandez"));
biblioteca.LibrosDisponibles.Add(new Libro("Rayuela", "Julio Cortazar"));

Console.WriteLine("Alta lector: " + biblioteca.altaLector("Gabriel", "12345678"));
Console.WriteLine("Alta duplicada: " + biblioteca.altaLector("Gabriel", "12345678"));
Console.WriteLine(biblioteca.prestarLibro("El Principito", "12345678"));
Console.WriteLine(biblioteca.prestarLibro("Don Quijote", "12345678"));
Console.WriteLine(biblioteca.prestarLibro("Martin Fierro", "12345678"));
Console.WriteLine(biblioteca.prestarLibro("Rayuela", "12345678"));
Console.WriteLine(biblioteca.prestarLibro("Libro desconocido", "12345678"));
Console.WriteLine(biblioteca.prestarLibro("Rayuela", "99999999"));