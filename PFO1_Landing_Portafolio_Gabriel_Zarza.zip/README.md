# PFO1 - Landing de Portafolio Personal

Este proyecto corresponde a la PFO1 y consiste en una landing page personal creada con HTML y CSS.

## Contenido

La página incluye:

- Nombre y apellido.
- Presentación personal.
- Habilidades.
- Sección personal "Sobre mí".
- Formulario de contacto.
- Enlace a GitHub.
- Diseño responsive.
- Google Fonts.
- Flexbox y CSS Grid.
- Transiciones.

## Archivos

- `index.html`
- `style.css`
- `imagen.jpg` (debe agregarse una imagen propia con este nombre)

## Publicación

Repositorio de GitHub: COMPLETAR

URL de Vercel: COMPLETAR

## Uso de inteligencia artificial

Utilicé ChatGPT como herramienta de apoyo para comprender la consigna y obtener ejemplos de estructura HTML y estilos CSS.

Plan utilizado: ChatGPT Plus.

Antes de realizar este trabajo tenía poca experiencia con HTML y CSS. Revisé el código generado y adapté textos, estructura y estilos según mi propio criterio.

Si se utiliza una imagen generada o modificada con inteligencia artificial, debe indicarse aquí.
