// La interactividad requerida se implementa con <details> y <summary> nativos.
// Estos elementos funcionan con clic y teclado sin JavaScript adicional.
// No se ejecuta IA, no hay llamadas a APIs ni backend.
'use strict';
