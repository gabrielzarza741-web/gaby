# TP3 — Dos sentencias, dos soluciones

**Equipo:** Grupo 33 · IFTS 29  
**Asignatura:** Desarrollo de Sistemas Web Front-End  
**Fecha de entrega indicada en la consigna:** 26/11/2026

## Estado y aclaración importante

**Prototipo funcional de ejemplo. No es una entrega oficial completa.** El nombre «Grupo 33 — Soluciones Digitales», el logo y las dos sentencias fueron **inventados a pedido para practicar**. La consigna pide la **startup real creada en IFTS 16**, su **logo original** y las **dos sentencias asignadas por el docente**. No se cuenta con esos datos, por lo que **no se inventaron como si fueran oficiales**.

## Descripción

Landing page de escritorio que presenta una startup de soporte técnico ficticia y explica visualmente dos posibles flujos agénticos. Muestra las condiciones lógicas, sus resultados para verdadero y falso, excepciones y situaciones de intervención humana. **No ejecuta agentes de IA, APIs ni backend.**

## Sentencias inventadas para la demostración

1. **Prioridad de atención:** «Si un cliente informa que el sistema no funciona **Y** el problema afecta a varios usuarios, la solicitud se considera urgente. En caso contrario, se registra como normal».
2. **Asignación de soporte:** «Si hay un técnico disponible **Y** el problema puede resolverse de forma remota, se asigna automáticamente. Si alguna de estas condiciones no se cumple, la solicitud se deriva a un encargado».

### Lógica de los flujos

| Flujo | Datos | Condición | Verdadero | Falso | Excepción |
|---|---|---|---|---|---|
| 1 | Sistema, usuarios afectados | Caído **Y** varios usuarios | Urgente | Normal | Datos incompletos → encargado |
| 2 | Técnico, resolución remota | Disponible **Y** remoto posible | Asignar técnico | Derivar | Datos no confirmados → encargado |

## Estructura

```text
TP3_Grupo33_COMPLETO/
├── index.html
├── styles.css
├── script.js
├── README.md
├── PROMPTS_Y_PRUEBAS.md
└── assets/
    └── logo-ejemplo.svg
```

## Tecnologías

- **HTML5:** estructura semántica, navegación, diagramas de bloques y desplegables accesibles (`details` y `summary`).
- **CSS3:** diseño visual y adaptación a pantallas pequeñas.
- **JavaScript:** archivo documental sin funciones necesarias; los desplegables son nativos de HTML.

## Ejecutar localmente

1. Descomprimir la carpeta.
2. Abrir `index.html` con un navegador.
3. Navegar a las propuestas y desplegar los detalles de cada flujo.

## Integrantes y contribuciones reales

> Completar con integrantes del **Grupo 33** y aportes efectivamente realizados. No se asume que coincidan con grupos de otros TP.

| Nombre y apellido | Aporte concreto |
|---|---|
| [Integrante 1] | [Rol y actividad real] |
| [Integrante 2] | [Rol y actividad real] |
| [Integrante 3] | [Rol y actividad real] |

## Construcción agéntica: herramientas y modelos

La consigna exige construir e iterar el sitio **100 % mediante agentes de programación**. Este prototipo fue generado mediante asistencia de ChatGPT en esta conversación. Antes de entregar, registrar con exactitud el agente de programación empleado, el modelo y las iteraciones reales. **No declarar herramientas ni pruebas que no se usaron.**

| Aplicación / entorno | Modelo | Uso |
|---|---|---|
| ChatGPT | GPT-6 | Generación del prototipo de ejemplo y documentación en esta conversación |
| [Agente de programación usado por el equipo] | [Modelo exacto o «modelo no informado»] | [Acciones realmente realizadas] |

El archivo `PROMPTS_Y_PRUEBAS.md` contiene una instrucción sugerida para el agente y una plantilla para documentar iteraciones y pruebas reales.

## Publicación

- **GitHub:** [Pegar URL del repositorio público]
- **Vercel o alternativa:** [Pegar URL de la landing publicada]

Publicar los archivos descomprimidos, con `index.html` en la raíz. Para Vercel usar el preset **Other** y despliegue estático sin compilación. Abrir ambos enlaces en una ventana de incógnito para comprobar acceso público.

## Pendientes obligatorios antes de la entrega

- [ ] Confirmar la startup del IFTS 16 asignada al Grupo 33 y reemplazar los datos inventados.
- [ ] Incorporar el logo original, completo y legible.
- [ ] Reemplazar las dos sentencias inventadas por las dos sentencias originales.
- [ ] Ajustar diagramas, condiciones, acciones y excepciones a las sentencias oficiales.
- [ ] Completar integrantes y contribuciones reales.
- [ ] Registrar herramientas, modelos, prompts, problemas y correcciones realmente utilizados.
- [ ] Probar desplegables con clic y teclado y verificar ambas ramas de cada condición.
- [ ] Publicar GitHub y landing y comprobar ambos enlaces sin iniciar sesión.

## Evaluación

La consigna considera participación, repositorio y landing, contenidos obligatorios, coherencia de los diagramas y registro de IA/modelos.
