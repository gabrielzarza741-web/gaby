# Guía de prompts, iteraciones y verificación — TP3 Grupo 33

## Prompt inicial sugerido para un agente de programación

> Construí una landing de escritorio con HTML, CSS y JavaScript sin framework, para el TP3 «Dos sentencias, dos soluciones». Usá el nombre provisional «Grupo 33 — Soluciones Digitales» y dejá explícito que es un ejemplo ficticio. Incorporá navegación, descripción de startup, dos sentencias originales en texto, un diagrama visual por sentencia con Inicio → Datos → Decisión → ramas SÍ/NO → Resultado, y un desplegable accesible para cada flujo con datos, condición, acción, excepciones e intervención humana. No implementes IA, APIs ni backend. Prepará README con integrantes, herramientas/modelos, prompts, iteraciones y enlaces como campos pendientes. No afirmes que los datos inventados son oficiales.

## Registro de iteraciones reales (completar después de realizarlas)

| Iteración | Instrucción al agente | Problema detectado | Corrección solicitada | Resultado verificado |
|---|---|---|---|---|
| 1 | [Prompt realmente usado] | [Problema real] | [Corrección real] | [Comprobación real] |
| 2 | [Prompt realmente usado] | [Problema real] | [Corrección real] | [Comprobación real] |

## Casos de prueba manuales

| Caso | Acción | Resultado esperado | Resultado observado | Estado |
|---|---|---|---|---|
| 1 | Abrir `index.html` | Página visible sin errores | [Completar] | Pendiente |
| 2 | Ir a «Soluciones» | Navega a la sección | [Completar] | Pendiente |
| 3 | Abrir primer desplegable con clic | Se muestra el detalle | [Completar] | Pendiente |
| 4 | Enfocar primer desplegable y pulsar Enter | Se abre/cierra | [Completar] | Pendiente |
| 5 | Flujo 1: sistema caído y varios usuarios | Rama SÍ → urgente | [Completar] | Pendiente |
| 6 | Flujo 1: alguna condición falsa | Rama NO → normal | [Completar] | Pendiente |
| 7 | Flujo 2: técnico disponible y remoto posible | Rama SÍ → asignar | [Completar] | Pendiente |
| 8 | Flujo 2: alguna condición falsa | Rama NO → derivar | [Completar] | Pendiente |
| 9 | Abrir GitHub en incógnito | Acceso sin sesión | [Completar] | Pendiente |
| 10 | Abrir Vercel en incógnito | Acceso sin sesión | [Completar] | Pendiente |

**Nota:** los diagramas son explicativos, no un simulador de ejecución. Los casos 5–8 se verifican recorriendo visualmente las ramas y leyendo sus resultados.
